<?php

$languageStrings = array(
    "Classroom"                 => "Учебный класс",
    "SINGLE_Classroom"          => "Учебный класс",
    "LBL_ADD_RECORD"            => "Добавить Учебный класс",
    "LBL_RECORDS_LIST"          => "Список Учебных классов",
    "LBL_CLASSROOM_INFORMATION" => "Информация о классе",
    "LBL_CLASSROOM_DESCRIPTION" => "Описание",
    "Name"                      => "Имя",
    "Status"                    => "Статус",
    "Type"                      => "Тип класса",
    "Assigned User"             => "Ответственный",
    "Description"               => "Описание",
    "Minimum pupils"                => "Минимальное кол-во учеников",
    "Maximum pupils"                => "Максимальное кол-во учеников",
);

// Начать исправление
include "renamed/Classroom.php";
